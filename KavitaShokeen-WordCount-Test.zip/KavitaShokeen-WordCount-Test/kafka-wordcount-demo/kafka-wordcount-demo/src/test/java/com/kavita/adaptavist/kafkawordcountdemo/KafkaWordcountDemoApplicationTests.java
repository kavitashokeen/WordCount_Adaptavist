package com.kavita.adaptavist.kafkawordcountdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaWordcountDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
